export class Store {
    // name:string;
    // imgUrl:string;
    // branches:string[]

    constructor(public name:string, public imgUrl:string, public branches:string[]){

        // this.name=nm;
        // this.imgUrl=imgUrl;
        // this.branches=branches;
    }
}
